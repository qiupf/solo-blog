title: Alfred使用简介
date: '2019-08-29 16:25:49'
updated: '2019-08-29 16:25:49'
tags: [mac]
permalink: /articles/2019/08/29/1567067149093.html
---
https://www.jianshu.com/p/e9f3352c785f
