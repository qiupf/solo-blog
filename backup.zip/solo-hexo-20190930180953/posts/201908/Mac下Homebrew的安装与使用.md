title: Mac下Homebrew的安装与使用
date: '2019-08-28 11:24:10'
updated: '2019-08-28 11:24:10'
tags: [mac]
permalink: /articles/2019/08/28/1566962649987.html
---
简介：https://www.jianshu.com/p/bca8fc1ff3f0
官网：https://brew.sh/index_zh-cn.html

注意：使用brew需要终端翻墙，脚本如下：
function proxy() {
 	export http_proxy = http://127.0.0.1:1087 && export https_proxy = http://127.0.0.1:1087
 	echo "已开启代理（ss is working...）";
}

function unproxy() {
	unset http_proxy && unset https_proxy
   	echo "已关闭代理 （ss is closed...）"
}
