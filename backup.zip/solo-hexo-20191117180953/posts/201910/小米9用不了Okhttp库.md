title: 小米9用不了Okhttp库
date: '2019-10-23 21:55:09'
updated: '2019-10-23 21:55:09'
tags: [android]
permalink: /articles/2019/10/23/1571838909169.html
---
报错如下：
![TIM图片20191023204908.png](https://img.hacpai.com/file/2019/10/TIM图片20191023204908-e53dddf9.png)

有待解决

