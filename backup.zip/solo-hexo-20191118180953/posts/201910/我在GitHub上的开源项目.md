title: 我在 GitHub 上的开源项目
date: '2019-10-06 17:59:53'
updated: '2019-10-06 17:59:53'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [solo-blog](https://github.com/qiupf/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/qiupf/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/qiupf/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/qiupf/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`http://www.meetpanda.xyz:8081`](http://www.meetpanda.xyz:8081 "项目主页")</span>

qiupf 的个人博客 - 记录精彩的程序人生



---

### 2. [wristband](https://github.com/qiupf/wristband) <kbd title="主要编程语言">Kotlin</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/qiupf/wristband/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/qiupf/wristband/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/qiupf/wristband/network/members "分叉数")</span>





---

### 3. [coolweather](https://github.com/qiupf/coolweather) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/qiupf/coolweather/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/qiupf/coolweather/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/qiupf/coolweather/network/members "分叉数")</span>





---

### 4. [javaee](https://github.com/qiupf/javaee) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/qiupf/javaee/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/qiupf/javaee/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/qiupf/javaee/network/members "分叉数")</span>



