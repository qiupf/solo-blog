title: iOS安装app
date: '2019-09-03 11:12:18'
updated: '2019-09-03 11:12:18'
tags: [ios]
permalink: /articles/2019/09/03/1567480338391.html
---
### Cydia Impactor
### PP助手
### 爱思助手
https://www.4spaces.org/ipad-install-ipa-without-jailbreak/
https://juejin.im/entry/5b7a38406fb9a019c77156f9

