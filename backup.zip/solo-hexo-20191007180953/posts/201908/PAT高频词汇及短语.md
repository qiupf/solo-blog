title: PAT高频词汇及短语
date: '2019-08-28 09:12:56'
updated: '2019-08-29 11:02:05'
tags: [pat词汇]
permalink: /articles/2019/08/28/1566954776154.html
---
Polynomials	n. [数] 多项式
for the sake of simplicity	为了简单起见

