title: 通过service后台定位
date: '2019-10-20 19:48:18'
updated: '2019-10-20 19:48:18'
tags: [android]
permalink: /articles/2019/10/20/1571572098569.html
---
```
package com.example.lbstest.service;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.example.lbstest.MainActivity;

public class PositionService extends Service {

    private static final String TAG = "PositionService";
    private LocationClient mLocationClient;

    @Override
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);
    }

    private class MyLocationListener implements BDLocationListener {
        @Override
        public void onReceiveLocation(final BDLocation bdLocation) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Log.e(TAG, "纬度：" + bdLocation.getLatitude() + "\t经度：" + bdLocation.getLongitude());
                }
            }).start();
        }
    }

    public class PositionBinder extends Binder {
        public void start(int n) {
            mLocationClient = new LocationClient(getApplicationContext());
            mLocationClient.registerLocationListener(new MyLocationListener());
            LocationClientOption option = new LocationClientOption();
            option.setScanSpan(n);
            mLocationClient.setLocOption(option);
            mLocationClient.start();
        }

        public void stop() {
            if (mLocationClient != null) {
                mLocationClient.stop();
            }
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return new PositionBinder();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e(TAG, "onDestroy");
    }
}

```






```
package com.example.lbstest;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.example.lbstest.service.PositionService;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    private EditText mSpantime;
    private Button mStart;
    private Button mStop;

    private PositionService.PositionBinder mPositionBinder;
    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            mPositionBinder = (PositionService.PositionBinder) iBinder;
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mSpantime = findViewById(R.id.span_time);
        mStart = findViewById(R.id.start);
        mStop = findViewById(R.id.stop);
        mStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, PositionService.class);
                bindService(intent, mConnection, BIND_AUTO_CREATE);
                if (mPositionBinder != null) {
                    mPositionBinder.start(Integer.valueOf(mSpantime.getText().toString()));

                }
            }
        });
        mStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mPositionBinder != null) {
                    mPositionBinder.stop();
                }
                //unbindService(mConnection);
            }
        });
        Intent intent = new Intent(this, PositionService.class);
        startService(intent);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e(TAG, "onDestroy ");
    }
}

```
