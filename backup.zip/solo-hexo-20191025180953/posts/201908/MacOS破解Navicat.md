title: MacOS 破解 Navicat
date: '2019-08-28 11:35:44'
updated: '2019-08-28 11:36:08'
tags: [mac]
permalink: /articles/2019/08/28/1566963344739.html
---
https://www.jianshu.com/p/f3ef78deadaa
https://www.jianshu.com/p/4e93b48f9f63

