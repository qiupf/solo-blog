title: PAT高频词汇及短语
date: '2019-08-28 09:12:56'
updated: '2019-08-28 09:12:56'
tags: [pat词汇]
permalink: /articles/2019/08/28/1566954776154.html
---
Polynomials	n. [数] 多项式
