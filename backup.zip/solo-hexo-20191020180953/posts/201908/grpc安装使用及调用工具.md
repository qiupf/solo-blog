title: grpc安装使用及调用工具
date: '2019-08-28 11:45:31'
updated: '2019-08-28 11:45:31'
tags: [golang]
permalink: /articles/2019/08/28/1566963931813.html
---
首先安装protoc：https://www.jianshu.com/p/ec3e75e5aad1
安装grpc：https://www.jianshu.com/p/dba4c7a6d608

命令：protoc --proto_path=. --go_out=plugins=grpc:. --micro_out=. --swagger_out=logtostderr=true:.  edgeserver-log.proto

调用工具：https://github.com/uw-labs/bloomrpc/releases



