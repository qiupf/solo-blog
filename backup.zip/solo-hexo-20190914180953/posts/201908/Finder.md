title: Finder
date: '2019-08-29 17:01:35'
updated: '2019-08-29 17:01:35'
tags: [mac]
permalink: /articles/2019/08/29/1567069294894.html
---
https://www.jianshu.com/p/6505ead00d59
