title: Json转go struct
date: '2019-08-28 11:37:20'
updated: '2019-08-28 11:37:20'
tags: [golang]
permalink: /articles/2019/08/28/1566963440031.html
---
https://mholt.github.io/json-to-go/
